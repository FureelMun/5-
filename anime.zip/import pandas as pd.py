import pandas as pd

# Загрузка датасета
dataset_url = "anime.csv"
df = pd.read_csv(dataset_url)

# Вывод всего датасета и его описание
print("Датасет:")
print(df)
print("\nОписание датасета:")
print(df.info())

# Размерность массива
print("\nРазмерность массива:")
print(df.shape)

# Наименование всех колонок и их описание
info_column = {"anime_id":"ID аниме",
               "name":"название аниме",
               "genre":"перечень жанров",
               "type":"как показывали",
               "episodes":"кол-во эпизодов",
               "rating":"рейтинг на сайтах, статистика",
               "members":"кол-во фанатов, статистика"}
print("\nКолонки и их описание:")
for column in df.columns:
    print(f"{column}:" + info_column[column])

# Вывод всех уникальных значений
print("\nУникальные значения:")

for column in df.columns:
    unique_values = df[column].unique()
    print(f"{column}: {unique_values}")

# Сортировка по определенным параметрам
sorted_df = df.sort_values(by="episodes")
print('kik')
# Удаление ненужных столбцов или строк
df = df.drop(columns=["members"])
df = df.drop(index=[1, 2, 3])
print('kik2')
# Замена определенных значений в датасете
df = df.fillna(value="значение")
print('kik3')
# Удаление дубликатов
df = df.drop_duplicates()
print('kik4')
# Анализ с помощью функции info
print("\nАнализ с помощью функции info:")
print(df.info())

# Анализ с помощью функции describe
print("\nАнализ с помощью функции describe:")
print(df.describe())

# Выборка данных по строкам и столбцам с помощью loc
selected_data = df.loc[df["episodes"] != 10]
print('kik5')
# Сохранение нового датасета
df.to_csv("Data_anime.csv", index=False)
print('kik6')
dataset_name = "Data_anime.csv"
df = pd.read_csv(dataset_name)
print(df.info())