import pandas as pd
import matplotlib.pyplot as plt

# Загрузка датасета
dataset_url = "Data_anime.csv"
df = pd.read_csv(dataset_url)

# Линейный график 1
plt.figure(figsize=(10, 6))
plt.plot(df["episodes"].head(100), label="Episodes")
plt.plot(df["rating"].head(20), label="Rating")
plt.xlabel("Index")
plt.ylabel("Value")
plt.title("Linear Plots")
plt.legend()
plt.show()

# Линейный график 2
plt.figure(figsize=(10, 6))
plt.plot(df["type"].head(100), label="type")
plt.plot(df["episodes"].head(10), label="episodes")
plt.xlabel("Index")
plt.ylabel("Value")
plt.title("Linear Plots 2")
plt.legend()
plt.show()

# Линейный график 3
plt.figure(figsize=(10, 6))
plt.plot(df["type"].head(100), label="type")
plt.plot(df["rating"].head(10), label="Rating")
plt.xlabel("Index")
plt.ylabel("Value")
plt.title("Linear Plots 3")
plt.legend()
plt.show()

# Столбчатая диаграмма
plt.figure(figsize=(10, 6))
plt.bar(df["type"].head(100), df["rating"].head(100))
plt.xlabel("type")
plt.ylabel("Rating")
plt.title("Bar Chart")
plt.xticks(rotation=90)
plt.show()

# Столбчатая диаграмма 2
plt.figure(figsize=(10, 6))
plt.bar(df["genre"].head(100), df["rating"].head(100))
plt.xlabel("Genre")
plt.ylabel("Rating")
plt.title("Bar Chart 2")
plt.xticks(rotation=90)
plt.show()

# Столбчатая диаграмма 3
plt.figure(figsize=(10, 6))
plt.bar(df["episodes"].head(100), df["rating"].head(100))
plt.xlabel("episodes")
plt.ylabel("Rating")
plt.title("Bar Chart 3")
plt.xticks(rotation=90)
plt.show()

# Круговая диаграмма
plt.figure(figsize=(10, 6))
plt.pie(df["type"].value_counts().head(4), labels=df["type"].unique()[:4], autopct='%1.1f%%')
plt.title("Pie Chart")
plt.show()

# Круговая диаграмма 2
rating_counts = df["episodes"].value_counts()
labels = rating_counts.index
sizes = rating_counts.values

plt.figure(figsize=(8, 8))
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
plt.axis('equal')
plt.title("Pie Chart 2")
#тяжело +- касячное
plt.show()

# Диаграмма рассеяния
plt.figure(figsize=(10, 6))
plt.scatter(df["rating"].head(100), df["type"].head(100))
plt.xlabel("Rating")
plt.ylabel("episodes")
plt.title("Scatter Plot")
plt.show()

# Диаграмма рассеяния 2
plt.figure(figsize=(10, 6))
plt.scatter(df["rating"].head(100), df["episodes"].head(100))
plt.xlabel("Rating")
plt.ylabel("episodes")
plt.title("Scatter Plot 2")
plt.show()

# Гистограмма
plt.figure(figsize=(10, 6))
plt.hist(df["episodes"].head(100), bins=10)
plt.xlabel("Episodes")
plt.ylabel("Frequency")
plt.title("Histogram")
plt.show()

# Гистограмма 2
plt.figure(figsize=(10, 6))
plt.hist(df["rating"].head(100), bins=10)
plt.xlabel("Rating")
plt.ylabel("Frequency")
plt.title("Histogram 2")
plt.show()

# Гистограмма 3
plt.figure(figsize=(10, 6))
plt.hist(df["type"].head(100), bins=10)
plt.xlabel("type")
plt.ylabel("Frequency")
plt.title("Histogram 3")
plt.show()

# ШПОРЫ
'''
plt.figure(figsize=(10, 6))
plt.xlabel()
plt.(df["тип данных"].head(диапозог))
plt.xlabel(заголовок х)
plt.ylabel(заголовок у)
plt.title(название диаграммы)
plt.show() изображение диаграммы

Два способа создания - боль, круговые страшные при создании(((
plt.figure(figsize=(10, 6))
plt.pie(df["type"].value_counts().head(4), labels=df["type"].unique()[:4], autopct='%1.1f%%')
plt.title("Pie Chart")
plt.show()

# Круговая диаграмма 2
rating_counts = df["episodes"].value_counts()
labels = rating_counts.index
sizes = rating_counts.values

plt.figure(figsize=(8, 8))
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
plt.axis('equal')
plt.title("Pie Chart 2")
'''